function varargout = Dashoard(varargin)
% DASHOARD MATLAB code for Dashoard.fig
%      DASHOARD, by itself, creates a new DASHOARD or raises the existing
%      singleton*.
%
%      H = DASHOARD returns the handle to a new DASHOARD or the handle to
%      the existing singleton*.
%
%      DASHOARD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DASHOARD.M with the given input arguments.
%
%      DASHOARD('Property','Value',...) creates a new DASHOARD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Dashoard_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Dashoard_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Dashoard

% Last Modified by GUIDE v2.5 05-Nov-2021 18:51:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Dashoard_OpeningFcn, ...
                   'gui_OutputFcn',  @Dashoard_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Dashoard is made visible.
function Dashoard_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Dashoard (see VARARGIN)

% Choose default command line output for Dashoard
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Dashoard wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Dashoard_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Histogram_btn.
function Histogram_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Histogram_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Dashoard)
Histogram


% --- Executes on button press in Contrast_Stretching_btn.
function Contrast_Stretching_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Contrast_Stretching_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Dashoard)
Contrast_Stretching


% --- Executes on button press in Bitplane_Slicing_btn.
function Bitplane_Slicing_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Bitplane_Slicing_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Dashoard)
Bitplane_Slicing

% --- Executes on button press in PL_Transmission_btn.
function PL_Transmission_btn_Callback(hObject, eventdata, handles)
% hObject    handle to PL_Transmission_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Dashoard)
PL_Transformation

% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Dashoard)
Intensity_Level_Transformation

% --- Executes on button press in Exit_btn.
function Exit_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Exit_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pause(0);
close();
close();


% --- Executes during object deletion, before destroying properties.
function figure1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('bg.png'); imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');
