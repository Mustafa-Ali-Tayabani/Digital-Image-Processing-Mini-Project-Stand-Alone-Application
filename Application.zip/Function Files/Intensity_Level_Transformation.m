function varargout = Intensity_Level_Transformation(varargin)
% Intensity_Level_Transformation MATLAB code for Intensity_Level_Transformation.fig
%      Intensity_Level_Transformation, by itself, creates a new Intensity_Level_Transformation or raises the existing
%      singleton*.
%
%      H = Intensity_Level_Transformation returns the handle to a new Intensity_Level_Transformation or the handle to
%      the existing singleton*.
%
%      Intensity_Level_Transformation('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in Intensity_Level_Transformation.M with the given input arguments.
%
%      Intensity_Level_Transformation('Property','Value',...) creates a new Intensity_Level_Transformation or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Intensity_Level_Transformation_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Intensity_Level_Transformation_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Intensity_Level_Transformation

% Last Modified by GUIDE v2.5 05-Nov-2021 22:19:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Intensity_Level_Transformation_OpeningFcn, ...
                   'gui_OutputFcn',  @Intensity_Level_Transformation_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Intensity_Level_Transformation is made visible.
function Intensity_Level_Transformation_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Intensity_Level_Transformation (see VARARGIN)

% Choose default command line output for Intensity_Level_Transformation
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Intensity_Level_Transformation wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Intensity_Level_Transformation_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Back_btn.
function Back_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Intensity_Level_Transformation)
Dashoard


% --- Executes on button press in Upload_btn.
function Upload_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global OriginalImage;
global FileName;
global PathName;

[FileName, PathName] = uigetfile('*.png;*.bmp;*.jpg', 'File Selector');
OriginalImage = strcat(PathName, FileName);
I = imread(OriginalImage);
axes(handles.Original); 
imshow(I), title("ORIGINAL IMAGE",'Color', '#F1F1F1' , 'Fontsize', 12);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

pause(0);
close();
close();



function HighThreshold_Value_text_Callback(hObject, eventdata, handles)
% hObject    handle to HighThreshold_Value_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of HighThreshold_Value_text as text
%        str2double(get(hObject,'String')) returns contents of HighThreshold_Value_text as a double


% --- Executes during object creation, after setting all properties.
function HighThreshold_Value_text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HighThreshold_Value_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Case_1_btn.
function Case_1_btn_Callback(hObject, eventdata, handles)

%CASE - 01
lt = str2double(get(handles.LowThreshold_Value_text,'String'));
ht = str2double(get(handles.HighThreshold_Value_text,'String'));
global OriginalImage;

x = im2gray(imread(OriginalImage));

% APPLYING INTENSITY LEVEL SLICIING 
y=x;
[w h]=size(x);
for i=1:w
    for j=1:h
        if x(i,j)>=lt && x(i,j)<=ht y(i,j)=255;
        else y(i,j)=0;
        end
    end
end

%MAPPING
dd=[];
hold on;
dd(1:100)=0;
dd(101:149)=255;
dd(150:256)=0;
axis tight;

%DISPLAYING
axes(handles.Gray); 
imshow(x), title("Gray Image",'Color', 'white' , 'Fontsize', 12);
axes(handles.axes2); 
imshow(y), title("CASE - 1",'Color', 'white' , 'Fontsize', 12);
axes(handles.axes3);
plot(dd), title("Intensity Level Transformation",'Color', 'white' , 'Fontsize', 12);
xlh = xlabel("Intensity in Input Image",'Color', 'white');
xlh.Position(2) = xlh.Position(2) - abs(xlh.Position(2) * 0.1);
ylabel("Intensity in Output Image",'Color', 'white');

% --- Executes on button press in Case_2_btn.
function Case_2_btn_Callback(hObject, eventdata, handles)
%CASE - 02

lt = str2double(get(handles.LowThreshold_Value_text,'String'));
ht = str2double(get(handles.HighThreshold_Value_text,'String'));
global OriginalImage;

% APPLYING INTENSITY LEVEL SLICIING 
x = im2gray(imread(OriginalImage));
y=x;
[w, h]=size(x);
for i=1:w
    for j=1:h
        if x(i,j)>=lt && x(i,j)<=ht y(i,j)=255;
        else y(i,j)=x(i,j);
        end
    end
end

%MAPPING
g2=[];
hold on;
g2(1:100)=0:99;
g2(101:149)=255;
g2(150:255)=150:255;
axis tight;

%DISPLAYING
axes(handles.axes10);
imshow(y), title("CASE - 2",'Color', 'white' , 'Fontsize', 12);
axes(handles.axes12);
plot(g2), title("Intensity Level Transformation",'Color', 'white' , 'Fontsize', 12);
xlh = xlabel("Intensity in Input Image",'Color', 'white');
xlh.Position(2) = xlh.Position(2) - abs(xlh.Position(2) * 0.1);
ylabel("Intensity in Output Image",'Color', 'white');


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('bg.png'); imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');
