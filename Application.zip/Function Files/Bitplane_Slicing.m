function varargout = Bitplane_Slicing(varargin)
% Bitplane_Slicing MATLAB code for Bitplane_Slicing.fig
%      Bitplane_Slicing, by itself, creates a new Bitplane_Slicing or raises the existing
%      singleton*.
%
%      H = Bitplane_Slicing returns the handle to a new Bitplane_Slicing or the handle to
%      the existing singleton*.
%
%      Bitplane_Slicing('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in Bitplane_Slicing.M with the given input arguments.
%
%      Bitplane_Slicing('Property','Value',...) creates a new Bitplane_Slicing or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Bitplane_Slicing_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Bitplane_Slicing_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Bitplane_Slicing

% Last Modified by GUIDE v2.5 05-Nov-2021 23:32:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Bitplane_Slicing_OpeningFcn, ...
                   'gui_OutputFcn',  @Bitplane_Slicing_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Bitplane_Slicing is made visible.
function Bitplane_Slicing_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Bitplane_Slicing (see VARARGIN)

% Choose default command line output for Bitplane_Slicing
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Bitplane_Slicing wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Bitplane_Slicing_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in Back_btn.
function Back_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Back_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Dashoard
close(Bitplane_Slicing)

% --- Executes on button press in back_btn.
function back_btn_Callback(hObject, eventdata, handles)
% hObject    handle to back_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

close(Bitplane_Slicing)
Dashoard

% --- Executes on button press in upload_btn.
function upload_btn_Callback(hObject, eventdata, handles)
% hObject    handle to upload_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global OriginalImage;
global FileName;
global PathName;

[FileName, PathName] = uigetfile('*.png;*.bmp;*.jpg', 'File Selector');
OriginalImage = strcat(PathName, FileName);
I = imread(OriginalImage);
axes(handles.Original); 
imshow(I), title("ORIGINAL IMAGE",'Color', '#F1F1F1' , 'Fontsize', 12);

% --- Executes on button press in exit_btn.
function exit_btn_Callback(hObject, eventdata, handles)
% hObject    handle to exit_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pause(0);
close();
close();


% --- Executes on button press in transform_btn.
function transform_btn_Callback(hObject, eventdata, handles)
% hObject    handle to transform_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global OriginalImage;
I=im2gray(imread(OriginalImage)); 

axes(handles.axes2);
B1 = mod(I, 2);
imshow(logical(B1)), title('BIT PLANE - 1', 'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes0);
B2 = mod(floor(I/2), 2);
imshow(logical(B2)), title('BIT PLANE - 2', 'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes3);
B3 = mod(floor(I/4), 2);
imshow(logical(B3)), title('BIT PLANE - 3', 'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes4);
B4 = mod(floor(I/8), 2);
imshow(logical(B4)), title('BIT PLANE - 4', 'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes5);
B5 = mod(floor(I/16), 2);
imshow(logical(B5)), title('BIT PLANE - 5', 'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes6);
B6 = mod(floor(I/32), 2);
imshow(logical(B6)), title('BIT PLANE - 6', 'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes7);
B7 = mod(floor(I/64), 2);
imshow(logical(B7)), title('BIT PLANE - 7', 'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes8);
B8 = mod(floor(I/128), 2);
imshow(logical(B8)), title('BIT PLANE - 8', 'Color', '#F1F1F1' , 'Fontsize', 12);


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('bg.png'); imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% BIT PLANE SLICING

delete(handles.Original);
delete(handles.axes2);
delete(handles.axes0);
delete(handles.axes3);
delete(handles.axes4);
delete(handles.axes5);
delete(handles.axes6);
delete(handles.axes7);
delete(handles.axes8);

global OriginalImage;
I2=im2gray(imread(OriginalImage)); 

axes(handles.axes10);
imshow(I2), title('ORIGINAL IMAGE', 'Color', '#F1F1F1' , 'Fontsize', 12);

Bit1 = mod(I2, 2);
Bit2 = mod(floor(I2/2), 2);
Bit3 = mod(floor(I2/4), 2);
Bit4 = mod(floor(I2/8), 2);
Bit5 = mod(floor(I2/16), 2);
Bit6 = mod(floor(I2/32), 2);
Bit7 = mod(floor(I2/64), 2);
Bit8 = mod(floor(I2/128), 2);

combine = (2 * (2 * (2 * (2 * (2 * (2 * (2 * Bit8 + Bit7) + Bit6) + Bit5) + Bit4) + Bit3) + Bit2) + Bit1);

axes(handles.axes11);
imshow(combine), title('COMBINED IMAGE', 'Color', '#F1F1F1' , 'Fontsize', 12);
