function varargout = Histogram(varargin)
% HISTOGRAM MATLAB code for Histogram.fig
%      HISTOGRAM, by itself, creates a new HISTOGRAM or raises the existing
%      singleton*.
%
%      H = HISTOGRAM returns the handle to a new HISTOGRAM or the handle to
%      the existing singleton*.
%
%      HISTOGRAM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HISTOGRAM.M with the given input arguments.
%
%      HISTOGRAM('Property','Value',...) creates a new HISTOGRAM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Histogram_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Histogram_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Histogram

% Last Modified by GUIDE v2.5 05-Nov-2021 18:57:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ... 
                   'gui_OpeningFcn', @Histogram_OpeningFcn, ...
                   'gui_OutputFcn',  @Histogram_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Histogram is made visible.
function Histogram_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Histogram (see VARARGIN)

% Choose default command line output for Histogram
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Histogram wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Histogram_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in Back_btn.
function Back_btn_Callback(hObject, eventdata, handles)
%it will direct to the dashboard window
Dashoard
%it will close the Histogram window
close(Histogram)

% --- Executes on button press in Upload_btn.
function Upload_btn_Callback(hObject, eventdata, handles)

global OriginalImage;
global FileName;
global PathName;

%using it to browse the file of an image
[FileName, PathName] = uigetfile('*.png;*.bmp;*.jpg', 'File Selector');
OriginalImage = strcat(PathName, FileName);
I = imread(OriginalImage);
axes(handles.Original_Image); 
imshow(I), title("ORIGINAL IMAGE",'Color', '#F1F1F1' , 'Fontsize', 12);

% --- Executes on button press in Histogram_btn.
function Histogram_btn_Callback(hObject, eventdata, handles)
global OriginalImage;

%Histogram Manual Function
x = imread(OriginalImage);
h=zeros(1,256);
[row, col, color]=size(x);
for color = 1:color
    for i=1:row
        for j=1:col
            f = x(i,j, color);
            h(1+f)=h(1+f)+1;
        end
    end
end
axis tight;
%Displaying this histogram to the defined Axes
axes(handles.Histogram);
NumberofPixels = 0: 255;
bar(NumberofPixels, h), title("ORIGINAL HISTOGRAM",'Color', '#F1F1F1' , 'Fontsize', 12);
xlabel("PIXEL INTENSITY",'Color', '#F1F1F1');
ylabel("PIXEL FREQUENCY",'Color', '#F1F1F1');


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pause(0);
close();
close();

% --- Executes during object creation, after setting all properties.
function Histogram_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Histogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate Histogram


% --- Executes on button press in Histogram_Equalization_btn.
function Histogram_Equalization_btn_Callback(hObject, eventdata, handles)

% HISTOGRAM EQUALIZATION ROUTINE

global OriginalImage
x = imread(OriginalImage);

h=zeros(1,256);
[r, c]=size(x);
total_no_of_pixels=r*c;

%Calculating Histogram without built-in function of the Image
for i=1:r
    for j=1:c
        h(x(i,j)+1)=h(x(i,j)+1)+1;
    end
end

%%
%Calculating Probability of the Image
for i=1:256
    h(i)=h(i)/total_no_of_pixels;
end

%%
%Calculating Cumulative Probability of the Image
temp=h(1);
for i=2:256
    temp=temp+h(i);
    h(i)=temp;
end

%%
%Mapping
for i=1:r
    for j=1:c
        x(i,j)=round(h(x(i,j)+1)*255);
    end
end
axis tight;
axes(handles.axes1);
imshow(x), title("EQUALIZED IMAGE",'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes2);

%%
%Mapping the equalized Histogram
h=zeros(1,256);
[row, col, color]=size(x);
for color = 1:color
    for i=1:row
        for j=1:col
            f = x(i,j, color);
            h(f+1)=h(f+1)+1;
        end
    end
end
NumberofPixels = 0: 255;
bar(NumberofPixels, h), title("HISTOGRAM EQULAIZATION",'Color', '#F1F1F1' , 'Fontsize', 12);
xlabel("PIXEL INTENSITY",'Color', '#F1F1F1');
ylabel("PIXEL FREQUENCY",'Color', '#F1F1F1');

% --- Executes on button press in Histogram_Normalization_btn.
function Histogram_Normalization_btn_Callback(hObject, eventdata, handles)
% HISTOGRAM NORMALIZATION WITHOUT BUILT IN FUNCTION
global OriginalImage;

x = imread(OriginalImage);
h=zeros(1,256);
[row, col, color]=size(x);
for color = 1:color
    for i=1:row
        for j=1:col
            f = x(i,j, color);
            h(1+f)=h(1+f)+1;
        end
    end
end
axis tight;
axes(handles.axes3);
imshow(x), title("ORIGINAL IMAGE",'Color', '#F1F1F1' , 'Fontsize', 12);
axes(handles.axes4);
NumberofPixels = 0: 255;
h=h/(row*col);
bar(NumberofPixels, h), title("NORMALIZED HISTOGRAM",'Color', '#F1F1F1' , 'Fontsize', 12);
xlabel("PIXEL INTENSITY",'Color', '#F1F1F1');
ylabel("PIXEL FREQUENCY",'Color', '#F1F1F1');

% --- Executes during object creation, after setting all properties.
function uipanel1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% create an axes that spans the whole gui
ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('bg.jpg'); imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('bg.png'); imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');
